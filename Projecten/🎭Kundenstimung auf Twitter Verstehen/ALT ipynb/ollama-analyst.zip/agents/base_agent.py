"""
Base Agent - Abstrakte Basis-Klasse fuer alle Analyse-Agents.
Jeder Agent (builtin oder generiert) muss davon erben.
"""

from abc import ABC, abstractmethod

import pandas as pd


class BaseAgent(ABC):
    """
    Abstrakte Basis-Klasse fuer CSV-Analyse-Agents.

    Jeder Agent hat:
        - name: Eindeutiger Name (z.B. "StatistikAgent")
        - description: Kurze Beschreibung (1 Satz)
        - keywords: Liste von deutschen Begriffen fuer Routing
        - system_prompt: Der Prompt der an Ollama geschickt wird

    Jeder Agent MUSS implementieren:
        - execute(df, frage, metadaten) -> str
    """

    def __init__(self):
        self.name: str = ""
        self.description: str = ""
        self.keywords: list = []
        self.system_prompt: str = ""

    @abstractmethod
    def execute(self, df: pd.DataFrame, frage: str, metadaten: dict) -> str:
        """
        Fuehrt die Analyse durch und gibt das Ergebnis als Text zurueck.

        Args:
            df: Der geladene CSV-DataFrame
            frage: Die Frage des Benutzers (auf Deutsch)
            metadaten: Dict mit CSV-Metadaten (Spalten, Typen, Beispiele)

        Returns:
            Antwort als String (auf Deutsch)
        """
        pass

    def matches_question(self, frage: str) -> bool:
        """
        Prueft ob dieser Agent zur Frage passt (Keyword-basiert).
        Wird als Fallback verwendet, falls Ollama nicht verfuegbar ist.
        """
        frage_lower = frage.lower()
        return any(kw in frage_lower for kw in self.keywords)

    def __repr__(self):
        return f"{self.name}: {self.description}"
