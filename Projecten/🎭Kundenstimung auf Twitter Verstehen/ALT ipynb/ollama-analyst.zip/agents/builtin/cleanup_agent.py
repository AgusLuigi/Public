"""
Cleanup Agent - Analysiert Datenqualitaet (Duplikate, fehlende Werte, Ausreisser).
Aendert NICHT die Daten, berichtet nur!
"""

import pandas as pd

from agents.base_agent import BaseAgent
from core import ollama_client, code_executor
from core.csv_loader import metadata_to_prompt


class CleanupAgent(BaseAgent):

    def __init__(self):
        super().__init__()
        self.name = "CleanupAgent"
        self.description = "Analysiert Datenqualitaet: Duplikate, fehlende Werte, Ausreisser und Inkonsistenzen."
        self.keywords = [
            'duplikat', 'duplikate', 'doppelt', 'fehlend', 'fehlende',
            'leer', 'nan', 'null', 'bereinig', 'qualitaet', 'sauber',
            'ausreisser', 'inkonsistenz', 'ungueltig', 'datenqualitaet',
        ]
        self.system_prompt = """Du bist ein Datenqualitaets-Experte. Du generierst pandas-Code um die Qualitaet eines Datensatzes zu pruefen.

WICHTIG: Du AENDERST keine Daten! Du analysierst und berichtest nur.

REGELN:
1. Generiere NUR Python-Code (kein Markdown, keine Erklaerungen)
2. Der DataFrame heisst 'df' und ist bereits geladen
3. Setze das Ergebnis in die Variable 'result'
4. Berichte auf Deutsch

BEISPIEL:
Frage: Wie ist die Datenqualitaet?
Code:
lines = ["Datenqualitaets-Bericht:\\n"]
lines.append(f"Gesamtzeilen: {len(df)}")
lines.append(f"Duplikate: {df.duplicated().sum()}")
lines.append(f"\\nFehlende Werte pro Spalte:")
missing = df.isnull().sum()
for col, count in missing.items():
    if count > 0:
        pct = count / len(df) * 100
        lines.append(f"  {col}: {count} ({pct:.1f}%)")
if missing.sum() == 0:
    lines.append("  Keine fehlenden Werte!")
result = '\\n'.join(lines)

Frage: Gibt es Ausreisser?
Code:
lines = ["Ausreisser-Analyse (IQR-Methode):\\n"]
numeric_cols = df.select_dtypes(include='number').columns
for col in numeric_cols:
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    outliers = df[(df[col] < lower) | (df[col] > upper)]
    if len(outliers) > 0:
        lines.append(f"  {col}: {len(outliers)} Ausreisser (Bereich: {lower:.2f} - {upper:.2f})")
if len(lines) == 1:
    lines.append("  Keine Ausreisser gefunden.")
result = '\\n'.join(lines)
"""

    def execute(self, df: pd.DataFrame, frage: str, metadaten: dict) -> str:
        meta_text = metadata_to_prompt(metadaten)

        code = ollama_client.chat(
            system_prompt=self.system_prompt,
            user_message=f"CSV-Metadaten:\n{meta_text}\n\nFrage: {frage}\n\nGeneriere den Code:"
        )

        result = code_executor.execute(code, df)

        if result['success']:
            if result['result'] is not None:
                return str(result['result'])
            elif result['output']:
                return result['output']
            else:
                return "Qualitaetsanalyse ausgefuehrt, aber kein Ergebnis."
        else:
            return f"Fehler bei der Qualitaetsanalyse: {result['error']}"
