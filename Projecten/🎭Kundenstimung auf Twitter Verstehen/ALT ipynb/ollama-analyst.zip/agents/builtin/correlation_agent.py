"""
Korrelations Agent - Findet Zusammenhaenge zwischen Spalten.
"""

import pandas as pd

from agents.base_agent import BaseAgent
from core import ollama_client, code_executor
from core.csv_loader import metadata_to_prompt


class CorrelationAgent(BaseAgent):

    def __init__(self):
        super().__init__()
        self.name = "KorrelationsAgent"
        self.description = "Findet Zusammenhaenge und Korrelationen zwischen numerischen Spalten."
        self.keywords = [
            'korrelation', 'zusammenhang', 'beziehung', 'einfluss',
            'abhaengigkeit', 'abhaengig', 'beeinflusst', 'wirkt',
            'zusammen', 'verbindung', 'kausalitaet',
        ]
        self.system_prompt = """Du bist ein Korrelations-Experte. Du generierst pandas-Code um Zusammenhaenge zwischen Spalten zu finden.

REGELN:
1. Generiere NUR Python-Code (kein Markdown, keine Erklaerungen)
2. Der DataFrame heisst 'df' und ist bereits geladen
3. Setze das Ergebnis in die Variable 'result'
4. Nutze df.corr(), scipy wenn noetig
5. Erklaere den Korrelationswert verstaendlich

INTERPRETATION:
- 0.0 bis 0.3: schwacher Zusammenhang
- 0.3 bis 0.7: mittlerer Zusammenhang
- 0.7 bis 1.0: starker Zusammenhang
- Negativ: gegenlaeufer Zusammenhang

BEISPIEL:
Frage: Gibt es einen Zusammenhang zwischen Preis und Menge?
Code:
corr = df['Preis'].corr(df['Menge'])
staerke = 'schwacher' if abs(corr) < 0.3 else 'mittlerer' if abs(corr) < 0.7 else 'starker'
richtung = 'positiver' if corr > 0 else 'negativer'
result = f"Korrelation zwischen Preis und Menge: {corr:.3f}\\nDas ist ein {staerke}, {richtung} Zusammenhang."

Frage: Welche Spalten korrelieren am staerksten?
Code:
corr_matrix = df.select_dtypes(include='number').corr()
pairs = []
for i in range(len(corr_matrix.columns)):
    for j in range(i+1, len(corr_matrix.columns)):
        col1 = corr_matrix.columns[i]
        col2 = corr_matrix.columns[j]
        val = corr_matrix.iloc[i, j]
        pairs.append((col1, col2, val))
pairs.sort(key=lambda x: abs(x[2]), reverse=True)
lines = ["Staerkste Korrelationen:\\n"]
for col1, col2, val in pairs[:5]:
    lines.append(f"  {col1} <-> {col2}: {val:.3f}")
result = '\\n'.join(lines)
"""

    def execute(self, df: pd.DataFrame, frage: str, metadaten: dict) -> str:
        meta_text = metadata_to_prompt(metadaten)

        code = ollama_client.chat(
            system_prompt=self.system_prompt,
            user_message=f"CSV-Metadaten:\n{meta_text}\n\nFrage: {frage}\n\nGeneriere den Code:"
        )

        result = code_executor.execute(code, df)

        if result['success']:
            if result['result'] is not None:
                return str(result['result'])
            elif result['output']:
                return result['output']
            else:
                return "Korrelationsanalyse ausgefuehrt, aber kein Ergebnis."
        else:
            return f"Fehler bei der Korrelationsanalyse: {result['error']}"
