"""
Filter Agent - Filtert und durchsucht Daten nach Kriterien.
"""

import pandas as pd

from agents.base_agent import BaseAgent
from core import ollama_client, code_executor
from core.csv_loader import metadata_to_prompt


class FilterAgent(BaseAgent):

    def __init__(self):
        super().__init__()
        self.name = "FilterAgent"
        self.description = "Filtert Daten nach Bedingungen, sucht bestimmte Eintraege und zeigt Teilmengen an."
        self.keywords = [
            'filter', 'filtern', 'suche', 'suchen', 'finde', 'finden',
            'zeige', 'zeig', 'wo', 'wenn', 'bedingung', 'groesser',
            'kleiner', 'gleich', 'zwischen', 'enthaelt', 'beginnt',
            'top', 'erste', 'letzte', 'sortiere', 'sortiert',
        ]
        self.system_prompt = """Du bist ein Daten-Filter-Experte. Du generierst pandas-Code um Daten zu filtern und zu durchsuchen.

REGELN:
1. Generiere NUR Python-Code (kein Markdown, keine Erklaerungen)
2. Der DataFrame heisst 'df' und ist bereits geladen
3. Setze das Ergebnis in die Variable 'result'
4. Bei vielen Ergebnissen: Limitiere auf maximal 20 Zeilen
5. Gib eine verstaendliche Zusammenfassung als String zurueck

BEISPIEL:
Frage: Zeige alle Kunden aus Berlin
Code:
filtered = df[df['Stadt'] == 'Berlin']
result = f"Gefunden: {len(filtered)} Kunden aus Berlin\\n\\n{filtered.head(20).to_string(index=False)}"

Frage: Top 5 nach Umsatz
Code:
top5 = df.nlargest(5, 'Umsatz')
result = f"Top 5 nach Umsatz:\\n\\n{top5.to_string(index=False)}"
"""

    def execute(self, df: pd.DataFrame, frage: str, metadaten: dict) -> str:
        meta_text = metadata_to_prompt(metadaten)

        code = ollama_client.chat(
            system_prompt=self.system_prompt,
            user_message=f"CSV-Metadaten:\n{meta_text}\n\nFrage: {frage}\n\nGeneriere den Code:"
        )

        result = code_executor.execute(code, df)

        if result['success']:
            if result['result'] is not None:
                return str(result['result'])
            elif result['output']:
                return result['output']
            else:
                return "Filter ausgefuehrt, aber kein Ergebnis."
        else:
            return f"Fehler beim Filtern: {result['error']}"
