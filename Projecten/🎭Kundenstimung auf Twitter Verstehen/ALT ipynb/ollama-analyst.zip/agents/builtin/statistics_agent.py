"""
Statistik Agent - Berechnet deskriptive Statistiken.
Mittelwert, Median, Standardabweichung, Min, Max, Quantile.
"""

import pandas as pd

from agents.base_agent import BaseAgent
from core import ollama_client, code_executor
from core.csv_loader import metadata_to_prompt


class StatisticsAgent(BaseAgent):

    def __init__(self):
        super().__init__()
        self.name = "StatistikAgent"
        self.description = "Berechnet Mittelwert, Median, Standardabweichung, Minimum, Maximum und andere statistische Kennzahlen."
        self.keywords = [
            'mittelwert', 'durchschnitt', 'median', 'standardabweichung',
            'minimum', 'maximum', 'min', 'max', 'summe', 'anzahl',
            'haeufigkeit', 'verteilung', 'quantil', 'varianz',
            'statistik', 'kennzahl', 'durchschnittlich', 'gesamt',
        ]
        self.system_prompt = """Du bist ein Daten-Statistik-Experte. Du generierst pandas-Code um statistische Fragen zu beantworten.

REGELN:
1. Generiere NUR Python-Code (kein Markdown, keine Erklaerungen)
2. Nutze pandas (als 'pd') und numpy (als 'np') - beide sind bereits importiert
3. Der DataFrame heisst 'df' und ist bereits geladen
4. Setze das Ergebnis in die Variable 'result'
5. 'result' soll ein einfacher Wert sein (Zahl, String oder kleiner DataFrame)
6. Nutze deutsche Zahlenformatierung wenn moeglich

BEISPIEL:
Frage: Was ist der durchschnittliche Umsatz?
Code:
result = f"Der durchschnittliche Umsatz betraegt {df['Umsatz'].mean():,.2f}"

Frage: Wie viele Eintraege gibt es?
Code:
result = f"Es gibt {len(df)} Eintraege im Datensatz."
"""

    def execute(self, df: pd.DataFrame, frage: str, metadaten: dict) -> str:
        meta_text = metadata_to_prompt(metadaten)

        prompt = f"""{self.system_prompt}

CSV-METADATEN:
{meta_text}

FRAGE: {frage}

Generiere den pandas-Code (NUR Code, keine Erklaerungen):"""

        code = ollama_client.chat(
            system_prompt=self.system_prompt,
            user_message=f"CSV-Metadaten:\n{meta_text}\n\nFrage: {frage}\n\nGeneriere den Code:"
        )

        result = code_executor.execute(code, df)

        if result['success']:
            if result['result'] is not None:
                return str(result['result'])
            elif result['output']:
                return result['output']
            else:
                return "Analyse abgeschlossen, aber kein Ergebnis erzeugt."
        else:
            return f"Fehler bei der Analyse: {result['error']}\n(Code: {result['code']})"
