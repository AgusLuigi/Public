"""
Aggregation Agent - Gruppiert Daten und berechnet Summen/Durchschnitte.
"""

import pandas as pd

from agents.base_agent import BaseAgent
from core import ollama_client, code_executor
from core.csv_loader import metadata_to_prompt


class AggregationAgent(BaseAgent):

    def __init__(self):
        super().__init__()
        self.name = "AggregationsAgent"
        self.description = "Gruppiert Daten und berechnet Summen, Durchschnitte und Zaehler pro Kategorie."
        self.keywords = [
            'gruppierung', 'gruppiere', 'pro', 'nach', 'je',
            'aufgeteilt', 'aufteilen', 'kategorie', 'zusammenfassung',
            'umsatz pro', 'anzahl pro', 'summe pro', 'durchschnitt pro',
            'vergleich', 'vergleiche', 'gegenueber',
        ]
        self.system_prompt = """Du bist ein Daten-Aggregations-Experte. Du generierst pandas-Code fuer GROUP BY Operationen.

REGELN:
1. Generiere NUR Python-Code (kein Markdown, keine Erklaerungen)
2. Der DataFrame heisst 'df' und ist bereits geladen
3. Setze das Ergebnis in die Variable 'result'
4. Nutze groupby(), pivot_table() oder aehnliche pandas-Funktionen
5. Formatiere das Ergebnis leserlich als String

BEISPIEL:
Frage: Umsatz pro Region
Code:
grouped = df.groupby('Region')['Umsatz'].sum().sort_values(ascending=False)
lines = [f"Umsatz pro Region:\\n"]
for region, umsatz in grouped.items():
    lines.append(f"  {region}: {umsatz:,.2f}")
result = '\\n'.join(lines)

Frage: Durchschnittliche Bestellmenge pro Monat
Code:
df['Monat'] = pd.to_datetime(df['Datum']).dt.month
grouped = df.groupby('Monat')['Menge'].mean()
lines = ["Durchschnittliche Bestellmenge pro Monat:\\n"]
for monat, menge in grouped.items():
    lines.append(f"  Monat {monat}: {menge:.1f}")
result = '\\n'.join(lines)
"""

    def execute(self, df: pd.DataFrame, frage: str, metadaten: dict) -> str:
        meta_text = metadata_to_prompt(metadaten)

        code = ollama_client.chat(
            system_prompt=self.system_prompt,
            user_message=f"CSV-Metadaten:\n{meta_text}\n\nFrage: {frage}\n\nGeneriere den Code:"
        )

        result = code_executor.execute(code, df)

        if result['success']:
            if result['result'] is not None:
                return str(result['result'])
            elif result['output']:
                return result['output']
            else:
                return "Aggregation ausgefuehrt, aber kein Ergebnis."
        else:
            return f"Fehler bei der Aggregation: {result['error']}"
