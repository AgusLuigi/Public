"""
CSV-Analyst - Offline Datenanalyse mit Ollama.
Hauptprogramm: CLI Interface.

Starten mit: python main.py
"""

import os
import sys

# Projektverzeichnis zum Python-Path hinzufuegen
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core import ollama_client, agent_registry
from core.csv_loader import load_csv, metadata_to_prompt
from core.orchestrator import route_question


BANNER = """
================================================
   CSV-Analyst (Ollama)
   Offline | Deutsch | Agent-basiert
================================================
"""

HELP_TEXT = """
Kommandos:
  exit     - Programm beenden
  new      - Neue CSV-Datei laden
  agents   - Alle verfuegbaren Agents anzeigen
  debug    - Debug-Modus ein/ausschalten
  schema   - CSV-Schema nochmal anzeigen
  help     - Diese Hilfe anzeigen
"""


def main():
    print(BANNER)

    # Ollama-Verbindung pruefen
    print("Pruefe Ollama-Verbindung...")
    if not ollama_client.test_connection():
        print("\nFEHLER: Ollama ist nicht erreichbar!")
        print("1. Installiere Ollama: https://ollama.com/download")
        print("2. Starte Ollama")
        print("3. Installiere ein Modell: ollama pull llama3.1:8b")
        print("4. Starte dieses Programm erneut")
        sys.exit(1)

    print("Ollama verbunden!\n")

    # Agent Registry initialisieren
    agent_registry.initialize()

    debug_mode = False
    df = None
    metadaten = None

    # CSV laden
    df, metadaten = _load_csv_interactive()
    if df is None:
        return

    # Frage-Schleife
    print(f"\nBereit! Stelle deine Fragen zur CSV-Datei.")
    print(f"Tippe 'help' fuer Kommandos.\n")

    while True:
        try:
            frage = input("\n> ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n\nAuf Wiedersehen!")
            break

        if not frage:
            continue

        # Kommandos pruefen
        frage_lower = frage.lower()

        if frage_lower in ('exit', 'quit', 'q', 'ende'):
            print("Auf Wiedersehen!")
            break

        if frage_lower in ('help', 'hilfe', 'h', '?'):
            print(HELP_TEXT)
            continue

        if frage_lower in ('new', 'neu', 'neue datei'):
            df, metadaten = _load_csv_interactive()
            if df is None:
                print("Keine Datei geladen. Alte Datei bleibt aktiv.")
            continue

        if frage_lower in ('agents', 'agent', 'agenten'):
            print(agent_registry.list_agents_for_display())
            continue

        if frage_lower in ('debug', 'debug on', 'debug off'):
            debug_mode = not debug_mode
            status = "AN" if debug_mode else "AUS"
            print(f"Debug-Modus: {status}")
            continue

        if frage_lower in ('schema', 'info', 'spalten'):
            print(f"\n{metadata_to_prompt(metadaten)}")
            continue

        # Frage an den Orchestrator weiterleiten
        print()
        try:
            antwort = route_question(frage, df, metadaten, debug=debug_mode)
            print(f"\n{antwort}")
        except ConnectionError as e:
            print(f"\nOllama-Verbindungsfehler: {e}")
        except Exception as e:
            print(f"\nFehler: {e}")
            if debug_mode:
                import traceback
                traceback.print_exc()


def _load_csv_interactive():
    """Interaktives CSV-Laden ueber CLI."""
    while True:
        try:
            filepath = input("CSV-Datei (Pfad oder 'exit'): ").strip()
        except (KeyboardInterrupt, EOFError):
            return None, None

        if filepath.lower() in ('exit', 'quit', 'q'):
            return None, None

        # Anfuehrungszeichen entfernen (Drag & Drop)
        filepath = filepath.strip('"').strip("'")

        if not filepath:
            continue

        try:
            print(f"Lade CSV...")
            df, metadaten = load_csv(filepath)
            print(f"\nGeladen: {metadaten['zeilen']} Zeilen, {metadaten['spalten_anzahl']} Spalten")
            print(f"Spalten: {', '.join(metadaten['spalten_namen'])}")
            return df, metadaten
        except FileNotFoundError:
            print(f"Datei nicht gefunden: {filepath}")
        except ValueError as e:
            print(f"Fehler: {e}")
        except Exception as e:
            print(f"Unerwarteter Fehler: {e}")


if __name__ == '__main__':
    main()
