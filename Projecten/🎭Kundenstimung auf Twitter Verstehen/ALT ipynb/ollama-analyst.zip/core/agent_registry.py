"""
Agent Registry - Verwaltet alle verfuegbaren Agents (builtin + generiert).
Speichert die Registry als JSON und laedt Agents dynamisch per importlib.
"""

import importlib
import json
import os


# Pfade relativ zum Projektverzeichnis
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REGISTRY_PATH = os.path.join(BASE_DIR, 'data', 'agent_registry.json')

# Vordefinierte builtin-Agents
BUILTIN_AGENTS = [
    {
        'name': 'StatistikAgent',
        'description': 'Berechnet Mittelwert, Median, Standardabweichung, Minimum, Maximum und andere statistische Kennzahlen.',
        'keywords': ['mittelwert', 'durchschnitt', 'median', 'standardabweichung', 'minimum', 'maximum', 'statistik'],
        'type': 'builtin',
        'module': 'agents.builtin.statistics_agent',
        'class': 'StatisticsAgent',
    },
    {
        'name': 'FilterAgent',
        'description': 'Filtert Daten nach Bedingungen, sucht bestimmte Eintraege und zeigt Teilmengen an.',
        'keywords': ['filter', 'suche', 'finde', 'zeige', 'wo', 'bedingung', 'sortiere', 'top'],
        'type': 'builtin',
        'module': 'agents.builtin.filter_agent',
        'class': 'FilterAgent',
    },
    {
        'name': 'AggregationsAgent',
        'description': 'Gruppiert Daten und berechnet Summen, Durchschnitte und Zaehler pro Kategorie.',
        'keywords': ['gruppierung', 'pro', 'nach', 'je', 'summe pro', 'anzahl pro', 'vergleich'],
        'type': 'builtin',
        'module': 'agents.builtin.aggregation_agent',
        'class': 'AggregationAgent',
    },
    {
        'name': 'KorrelationsAgent',
        'description': 'Findet Zusammenhaenge und Korrelationen zwischen numerischen Spalten.',
        'keywords': ['korrelation', 'zusammenhang', 'beziehung', 'einfluss', 'abhaengigkeit'],
        'type': 'builtin',
        'module': 'agents.builtin.correlation_agent',
        'class': 'CorrelationAgent',
    },
    {
        'name': 'CleanupAgent',
        'description': 'Analysiert Datenqualitaet: Duplikate, fehlende Werte, Ausreisser und Inkonsistenzen.',
        'keywords': ['duplikat', 'fehlend', 'leer', 'nan', 'qualitaet', 'ausreisser', 'datenqualitaet'],
        'type': 'builtin',
        'module': 'agents.builtin.cleanup_agent',
        'class': 'CleanupAgent',
    },
]


def _load_registry() -> list:
    """Laedt die Registry-Datei. Erstellt sie falls nicht vorhanden."""
    if not os.path.exists(REGISTRY_PATH):
        _save_registry(BUILTIN_AGENTS)
        return BUILTIN_AGENTS

    with open(REGISTRY_PATH, 'r', encoding='utf-8') as f:
        data = json.load(f)

    return data.get('agents', [])


def _save_registry(agents: list):
    """Speichert die Agent-Liste in die Registry-Datei."""
    os.makedirs(os.path.dirname(REGISTRY_PATH), exist_ok=True)
    with open(REGISTRY_PATH, 'w', encoding='utf-8') as f:
        json.dump({'agents': agents}, f, ensure_ascii=False, indent=2)


def initialize():
    """
    Initialisiert die Registry. Stellt sicher dass alle
    builtin-Agents registriert sind.
    """
    agents = _load_registry()

    existing_names = {a['name'] for a in agents}
    for builtin in BUILTIN_AGENTS:
        if builtin['name'] not in existing_names:
            agents.append(builtin)

    _save_registry(agents)


def get_all_agents() -> list:
    """Gibt alle registrierten Agent-Metadaten zurueck."""
    return _load_registry()


def get_agent_instance(agent_name: str):
    """
    Laedt eine Agent-Klasse dynamisch und gibt eine Instanz zurueck.

    Args:
        agent_name: Name des Agents (z.B. "StatistikAgent")

    Returns:
        Instanz des Agents (erbt von BaseAgent)

    Raises:
        ValueError: Agent nicht gefunden
        ImportError: Modul konnte nicht geladen werden
    """
    agents = _load_registry()

    agent_meta = None
    for a in agents:
        if a['name'] == agent_name:
            agent_meta = a
            break

    if agent_meta is None:
        raise ValueError(f"Agent '{agent_name}' nicht in Registry gefunden.")

    module_path = agent_meta['module']
    class_name = agent_meta['class']

    # Fuer generierte Agents: Sicherstellen dass der Pfad stimmt
    if agent_meta.get('type') == 'generated':
        # agents.generated.xyz -> Datei muss existieren
        file_path = os.path.join(BASE_DIR, module_path.replace('.', os.sep) + '.py')
        if not os.path.exists(file_path):
            raise ImportError(f"Agent-Datei nicht gefunden: {file_path}")

    module = importlib.import_module(module_path)
    agent_class = getattr(module, class_name)
    return agent_class()


def add_agent(name: str, description: str, keywords: list,
              module: str, class_name: str) -> dict:
    """
    Fuegt einen neuen (generierten) Agent zur Registry hinzu.

    Returns:
        Dict mit den Agent-Metadaten
    """
    agents = _load_registry()

    # Pruefen ob Name schon existiert
    existing_names = {a['name'] for a in agents}
    if name in existing_names:
        # Suffix anhaengen
        counter = 2
        while f"{name}_v{counter}" in existing_names:
            counter += 1
        name = f"{name}_v{counter}"

    agent_meta = {
        'name': name,
        'description': description,
        'keywords': keywords,
        'type': 'generated',
        'module': module,
        'class': class_name,
    }

    agents.append(agent_meta)
    _save_registry(agents)

    return agent_meta


def list_agents_for_display() -> str:
    """Formatiert die Agent-Liste fuer CLI-Ausgabe."""
    agents = _load_registry()
    lines = [f"Verfuegbare Agents ({len(agents)}):\n"]
    for a in agents:
        agent_type = "[builtin]" if a.get('type') == 'builtin' else "[generiert]"
        lines.append(f"  {agent_type} {a['name']}: {a['description']}")
    return '\n'.join(lines)
