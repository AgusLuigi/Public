"""
Agent Creator - Erstellt dynamisch neue Analyse-Agents per LLM.
Das Killer-Feature: Wenn kein Agent zur Frage passt, wird einer gebaut.
"""

import os
import re

from core import ollama_client, agent_registry
from core.csv_loader import metadata_to_prompt


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROMPTS_DIR = os.path.join(BASE_DIR, 'prompts')
GENERATED_DIR = os.path.join(BASE_DIR, 'agents', 'generated')


def create_agent(frage: str, metadaten: dict) -> dict:
    """
    Erstellt einen neuen Agent basierend auf der Frage.

    1. Fragt Ollama nach einem Agent-Klassennamen + Code
    2. Speichert den Code als .py Datei in agents/generated/
    3. Registriert den Agent in der Registry
    4. Gibt die Agent-Metadaten zurueck

    Args:
        frage: Die Frage die keiner der bestehenden Agents beantworten konnte
        metadaten: CSV-Metadaten

    Returns:
        Dict mit Agent-Metadaten (name, module, class, etc.)
    """
    # Prompt laden
    try:
        creator_prompt = _load_prompt('agent_creator.txt')
    except FileNotFoundError:
        creator_prompt = _default_creator_prompt()

    try:
        template = _load_prompt('agent_template.txt')
    except FileNotFoundError:
        template = _default_template()

    meta_text = metadata_to_prompt(metadaten)

    user_message = (
        f"FRAGE DIE BEANTWORTET WERDEN SOLL:\n{frage}\n\n"
        f"CSV-METADATEN:\n{meta_text}\n\n"
        f"TEMPLATE:\n{template}\n\n"
        f"Generiere jetzt die komplette Agent-Klasse:"
    )

    response = ollama_client.chat(
        system_prompt=creator_prompt,
        user_message=user_message
    )

    # Code bereinigen
    code = _clean_generated_code(response)

    # Klassenname und Info extrahieren
    class_name = _extract_class_name(code)
    agent_name = _extract_agent_name(code)
    description = _extract_description(code)
    keywords = _extract_keywords(code)

    if not class_name:
        raise ValueError("Konnte keinen Klassennamen aus dem generierten Code extrahieren.")

    # Dateiname aus Klassenname ableiten
    file_name = _class_to_filename(class_name)
    file_path = os.path.join(GENERATED_DIR, f"{file_name}.py")

    # Code speichern
    os.makedirs(GENERATED_DIR, exist_ok=True)
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(code)

    # In Registry eintragen
    module_path = f"agents.generated.{file_name}"
    agent_meta = agent_registry.add_agent(
        name=agent_name or class_name,
        description=description or f"Automatisch erstellter Agent fuer: {frage}",
        keywords=keywords or _generate_keywords(frage),
        module=module_path,
        class_name=class_name,
    )

    return agent_meta


def _load_prompt(filename: str) -> str:
    filepath = os.path.join(PROMPTS_DIR, filename)
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()


def _clean_generated_code(code: str) -> str:
    """Bereinigt LLM-generierten Code."""
    # Markdown Code-Bloecke entfernen
    code = re.sub(r'^```(?:python)?\s*\n', '', code, flags=re.MULTILINE)
    code = re.sub(r'\n```\s*$', '', code, flags=re.MULTILINE)
    code = code.strip()

    # Sicherstellen dass noetige Imports vorhanden sind
    if 'from agents.base_agent import BaseAgent' not in code:
        imports = (
            'import pandas as pd\n\n'
            'from agents.base_agent import BaseAgent\n'
            'from core import ollama_client, code_executor\n'
            'from core.csv_loader import metadata_to_prompt\n\n\n'
        )
        code = imports + code

    return code


def _extract_class_name(code: str) -> str:
    """Extrahiert den Klassennamen aus dem generierten Code."""
    match = re.search(r'class\s+(\w+)\s*\(', code)
    return match.group(1) if match else None


def _extract_agent_name(code: str) -> str:
    """Extrahiert self.name aus dem generierten Code."""
    match = re.search(r'self\.name\s*=\s*["\']([^"\']+)["\']', code)
    return match.group(1) if match else None


def _extract_description(code: str) -> str:
    """Extrahiert self.description aus dem generierten Code."""
    match = re.search(r'self\.description\s*=\s*["\']([^"\']+)["\']', code)
    return match.group(1) if match else None


def _extract_keywords(code: str) -> list:
    """Extrahiert self.keywords aus dem generierten Code."""
    match = re.search(r'self\.keywords\s*=\s*\[(.*?)\]', code, re.DOTALL)
    if match:
        content = match.group(1)
        keywords = re.findall(r'["\']([^"\']+)["\']', content)
        return keywords
    return []


def _generate_keywords(frage: str) -> list:
    """Generiert Keywords aus der Frage als Fallback."""
    stopwords = {'was', 'ist', 'der', 'die', 'das', 'ein', 'eine', 'und',
                 'oder', 'in', 'von', 'fuer', 'zu', 'den', 'dem', 'des',
                 'mit', 'auf', 'an', 'es', 'wie', 'welche', 'welcher'}
    words = frage.lower().split()
    return [w for w in words if w not in stopwords and len(w) > 2]


def _class_to_filename(class_name: str) -> str:
    """Konvertiert CamelCase zu snake_case fuer Dateinamen."""
    # ABCAnalyseAgent -> abc_analyse_agent
    s1 = re.sub(r'(.)([A-Z][a-z]+)', r'\1_\2', class_name)
    return re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', s1).lower()


def _default_creator_prompt() -> str:
    return """Du bist ein Python-Experte, der spezialisierte Daten-Analyse-Agents erstellt.

Erstelle eine Python-Klasse die von BaseAgent erbt und eine bestimmte Analyse-Aufgabe loest.

REGELN:
1. Die Klasse MUSS von BaseAgent erben
2. Die Klasse MUSS __init__ mit name, description, keywords und system_prompt haben
3. Die Klasse MUSS execute(self, df, frage, metadaten) implementieren
4. execute() MUSS einen String zurueckgeben (deutsche Antwort)
5. Nutze ollama_client.chat() fuer LLM-Aufrufe
6. Nutze code_executor.execute() fuer Code-Ausfuehrung
7. Gib NUR den Python-Code zurueck (kein Markdown)

WICHTIG: Alle Antworten auf Deutsch!"""


def _default_template() -> str:
    return '''class MeinAgent(BaseAgent):

    def __init__(self):
        super().__init__()
        self.name = "MeinAgent"
        self.description = "Beschreibung was der Agent macht"
        self.keywords = ['keyword1', 'keyword2', 'keyword3']
        self.system_prompt = """Du bist ein Experte fuer XYZ..."""

    def execute(self, df, frage, metadaten):
        from core.csv_loader import metadata_to_prompt
        meta_text = metadata_to_prompt(metadaten)

        code = ollama_client.chat(
            system_prompt=self.system_prompt,
            user_message=f"CSV-Metadaten:\\n{meta_text}\\n\\nFrage: {frage}\\n\\nGeneriere den Code:"
        )

        result = code_executor.execute(code, df)

        if result['success'] and result['result'] is not None:
            return str(result['result'])
        elif result['output']:
            return result['output']
        else:
            return f"Fehler: {result.get('error', 'Unbekannt')}"
'''
