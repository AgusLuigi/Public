"""
Code Executor - Fuehrt LLM-generierten Python-Code sicher aus.
Erlaubt nur pandas/numpy/math, blockiert Dateizugriff und Netzwerk.
"""

import threading
import math
import re
from datetime import datetime, timedelta

import numpy as np
import pandas as pd


# Diese Module/Funktionen sind ERLAUBT im generierten Code
SAFE_BUILTINS = {
    'abs': abs,
    'all': all,
    'any': any,
    'bool': bool,
    'dict': dict,
    'enumerate': enumerate,
    'filter': filter,
    'float': float,
    'format': format,
    'frozenset': frozenset,
    'int': int,
    'isinstance': isinstance,
    'len': len,
    'list': list,
    'map': map,
    'max': max,
    'min': min,
    'print': print,
    'range': range,
    'reversed': reversed,
    'round': round,
    'set': set,
    'slice': slice,
    'sorted': sorted,
    'str': str,
    'sum': sum,
    'tuple': tuple,
    'type': type,
    'zip': zip,
    'True': True,
    'False': False,
    'None': None,
}

# Diese Patterns sind VERBOTEN
FORBIDDEN_PATTERNS = [
    r'\bimport\b',       # Keine Imports
    r'\bopen\b\s*\(',    # Kein Dateizugriff
    r'\bexec\b\s*\(',    # Kein exec in exec
    r'\beval\b\s*\(',    # Kein eval
    r'\b__import__\b',   # Kein dynamischer Import
    r'\bos\.',           # Kein OS-Zugriff
    r'\bsys\.',          # Kein Sys-Zugriff
    r'\bsubprocess\b',   # Kein Subprocess
    r'\bglobals\b\s*\(', # Kein globals()
    r'\bgetattr\b',      # Kein getattr
    r'\bsetattr\b',      # Kein setattr
    r'\bdelattr\b',      # Kein delattr
    r'\bcompile\b\s*\(', # Kein compile
    r'\b__\w+__\b',      # Keine dunder-Methoden (ausser __name__)
]


def validate_code(code: str) -> tuple:
    """
    Prueft ob der Code sicher ist.

    Returns:
        Tuple von (ist_sicher: bool, grund: str)
    """
    for pattern in FORBIDDEN_PATTERNS:
        match = re.search(pattern, code)
        if match:
            return False, f"Verbotenes Pattern gefunden: {match.group()}"

    return True, "OK"


def clean_code(code: str) -> str:
    """
    Bereinigt LLM-generierten Code:
    - Entfernt Markdown Code-Bloecke
    - Entfernt fuehrende/nachfolgende Leerzeilen
    """
    # Markdown Code-Block entfernen (```python ... ```)
    code = re.sub(r'^```(?:python)?\s*\n', '', code, flags=re.MULTILINE)
    code = re.sub(r'\n```\s*$', '', code, flags=re.MULTILINE)
    code = code.strip()
    return code


def execute(code: str, df: pd.DataFrame, timeout: int = 10) -> dict:
    """
    Fuehrt Python-Code sicher aus.

    Args:
        code: Der auszufuehrende Python-Code
        df: Der DataFrame auf dem gearbeitet wird
        timeout: Maximale Ausfuehrungszeit in Sekunden

    Returns:
        Dict mit:
            - success: bool
            - result: Der Wert der Variable 'result' (oder None)
            - output: Print-Ausgaben
            - error: Fehlermeldung (falls gescheitert)
            - code: Der ausgefuehrte Code (bereinigt)
    """
    code = clean_code(code)

    # Sicherheitscheck
    is_safe, reason = validate_code(code)
    if not is_safe:
        return {
            'success': False,
            'result': None,
            'output': '',
            'error': f"Sicherheitspruefung fehlgeschlagen: {reason}",
            'code': code,
        }

    # Erlaubte Globals zusammenstellen
    safe_globals = {
        '__builtins__': SAFE_BUILTINS,
        'pd': pd,
        'np': np,
        'math': math,
        'datetime': datetime,
        'timedelta': timedelta,
        'df': df.copy(),  # Kopie, damit Original nicht veraendert wird
    }

    local_vars = {}
    captured_output = []

    # Print umleiten
    original_print = SAFE_BUILTINS['print']

    def captured_print(*args, **kwargs):
        captured_output.append(' '.join(str(a) for a in args))

    safe_globals['__builtins__']['print'] = captured_print

    # Ausfuehrung mit Timeout
    exec_error = [None]

    def run_code():
        try:
            exec(code, safe_globals, local_vars)
        except Exception as e:
            exec_error[0] = e

    thread = threading.Thread(target=run_code)
    thread.start()
    thread.join(timeout=timeout)

    # Print wiederherstellen
    SAFE_BUILTINS['print'] = original_print

    if thread.is_alive():
        return {
            'success': False,
            'result': None,
            'output': '\n'.join(captured_output),
            'error': f"Timeout: Code hat laenger als {timeout}s gedauert",
            'code': code,
        }

    if exec_error[0]:
        return {
            'success': False,
            'result': None,
            'output': '\n'.join(captured_output),
            'error': str(exec_error[0]),
            'code': code,
        }

    result = local_vars.get('result', None)

    # DataFrame-Ergebnis als String formatieren
    if isinstance(result, pd.DataFrame):
        result = result.to_string(index=True)
    elif isinstance(result, pd.Series):
        result = result.to_string()

    return {
        'success': True,
        'result': result,
        'output': '\n'.join(captured_output),
        'error': None,
        'code': code,
    }
