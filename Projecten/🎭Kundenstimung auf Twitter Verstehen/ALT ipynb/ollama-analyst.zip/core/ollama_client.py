"""
Ollama Client - Wrapper fuer die Ollama Python SDK.
Stellt chat() bereit fuer alle LLM-Aufrufe im System.
"""

import json
import os

import ollama


def _load_config():
    """Laedt config.json aus dem Projektverzeichnis."""
    config_path = os.path.join(os.path.dirname(__file__), '..', 'config.json')
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def chat(system_prompt: str, user_message: str, model: str = None) -> str:
    """
    Sendet eine Nachricht an Ollama und gibt die Antwort zurueck.

    Args:
        system_prompt: System-Prompt (Rolle/Kontext)
        user_message: Die eigentliche Frage/Aufgabe
        model: Ollama Modell (falls None, wird aus config.json gelesen)

    Returns:
        Antwort-Text als String

    Raises:
        ConnectionError: Wenn Ollama nicht erreichbar ist
        RuntimeError: Bei sonstigen Ollama-Fehlern
    """
    config = _load_config()
    model = model or config.get('ollama', {}).get('model', 'llama3.1:8b')

    messages = [
        {'role': 'system', 'content': system_prompt},
        {'role': 'user', 'content': user_message},
    ]

    try:
        response = ollama.chat(model=model, messages=messages)
        return response['message']['content'].strip()
    except ollama.ResponseError as e:
        raise RuntimeError(
            f"Ollama-Fehler: {e}\n"
            f"Ist das Modell '{model}' installiert? Pruefe mit: ollama list"
        )
    except Exception as e:
        error_msg = str(e).lower()
        if 'connection' in error_msg or 'refused' in error_msg:
            raise ConnectionError(
                "Ollama ist nicht erreichbar!\n"
                "Starte Ollama und versuche es erneut.\n"
                "Download: https://ollama.com/download"
            )
        raise RuntimeError(f"Unbekannter Fehler bei Ollama-Aufruf: {e}")


def chat_stream(system_prompt: str, user_message: str, model: str = None):
    """
    Wie chat(), aber mit Streaming (gibt Chunks zurueck).
    Nuetzlich fuer laengere Antworten.

    Yields:
        Einzelne Text-Chunks
    """
    config = _load_config()
    model = model or config.get('ollama', {}).get('model', 'llama3.1:8b')

    messages = [
        {'role': 'system', 'content': system_prompt},
        {'role': 'user', 'content': user_message},
    ]

    try:
        for chunk in ollama.chat(model=model, messages=messages, stream=True):
            content = chunk.get('message', {}).get('content', '')
            if content:
                yield content
    except Exception as e:
        error_msg = str(e).lower()
        if 'connection' in error_msg or 'refused' in error_msg:
            raise ConnectionError(
                "Ollama ist nicht erreichbar!\n"
                "Starte Ollama und versuche es erneut."
            )
        raise RuntimeError(f"Ollama Streaming-Fehler: {e}")


def test_connection() -> bool:
    """Prueft ob Ollama erreichbar ist und ein Modell geladen ist."""
    try:
        models = ollama.list()
        model_names = [m.get('name', '') for m in models.get('models', [])]
        if not model_names:
            print("WARNUNG: Keine Modelle installiert!")
            print("Installiere ein Modell: ollama pull llama3.1:8b")
            return False
        return True
    except Exception:
        return False
