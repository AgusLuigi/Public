"""
Orchestrator - Das Gehirn des Systems.
Nimmt eine Frage entgegen, waehlt den passenden Agent und fuehrt ihn aus.
Falls kein Agent passt, wird ein neuer erstellt.
"""

import os

import pandas as pd

from core import ollama_client, agent_registry
from core.agent_creator import create_agent
from core.csv_loader import metadata_to_prompt


# Prompt-Template laden
PROMPTS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'prompts')


def _load_prompt(filename: str) -> str:
    """Laedt ein Prompt-Template aus dem prompts/ Verzeichnis."""
    filepath = os.path.join(PROMPTS_DIR, filename)
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()


def _build_agent_list() -> str:
    """Erstellt eine formatierte Liste aller Agents fuer den Routing-Prompt."""
    agents = agent_registry.get_all_agents()
    lines = []
    for a in agents:
        lines.append(f"- {a['name']}: {a['description']}")
    return '\n'.join(lines)


def route_question(frage: str, df: pd.DataFrame, metadaten: dict,
                   debug: bool = False) -> str:
    """
    Nimmt eine Frage, waehlt den passenden Agent und gibt die Antwort zurueck.

    Args:
        frage: Die Frage des Benutzers
        df: Der geladene DataFrame
        metadaten: CSV-Metadaten
        debug: Wenn True, wird der generierte Code angezeigt

    Returns:
        Antwort als String
    """
    # Schritt 1: Agent auswaehlen via Ollama
    agent_name = _select_agent(frage, metadaten)

    if debug:
        print(f"  [DEBUG] Gewaehlter Agent: {agent_name}")

    # Schritt 2: Agent ausfuehren oder erstellen
    if agent_name == "NONE" or agent_name is None:
        print("  Kein passender Agent gefunden. Erstelle neuen Agent...")
        return _create_and_run(frage, df, metadaten, debug)

    try:
        agent = agent_registry.get_agent_instance(agent_name)
        print(f"  [{agent.name}]")
        return agent.execute(df, frage, metadaten)
    except (ValueError, ImportError) as e:
        print(f"  Agent '{agent_name}' nicht ladbar: {e}")
        print(f"  Erstelle neuen Agent...")
        return _create_and_run(frage, df, metadaten, debug)


def _select_agent(frage: str, metadaten: dict) -> str:
    """Fragt Ollama welcher Agent zur Frage passt."""
    try:
        prompt_template = _load_prompt('orchestrator.txt')
    except FileNotFoundError:
        prompt_template = _default_orchestrator_prompt()

    agent_list = _build_agent_list()
    meta_text = metadata_to_prompt(metadaten)

    user_message = (
        f"Verfuegbare Agents:\n{agent_list}\n\n"
        f"CSV-Metadaten:\n{meta_text}\n\n"
        f"Frage: {frage}\n\n"
        f"Welcher Agent passt? Antworte NUR mit dem Agent-Namen oder NONE:"
    )

    try:
        response = ollama_client.chat(
            system_prompt=prompt_template,
            user_message=user_message
        )
    except (ConnectionError, RuntimeError) as e:
        print(f"  Ollama-Fehler beim Routing: {e}")
        print(f"  Fallback: Keyword-basierte Auswahl...")
        return _keyword_fallback(frage)

    # Antwort bereinigen
    agent_name = response.strip().strip('"').strip("'")

    # Pruefen ob der Name in der Registry existiert
    known_names = {a['name'] for a in agent_registry.get_all_agents()}
    if agent_name in known_names:
        return agent_name

    # Fuzzy Match: Vielleicht hat Ollama leicht anders geschrieben
    for name in known_names:
        if name.lower() in agent_name.lower() or agent_name.lower() in name.lower():
            return name

    return "NONE"


def _keyword_fallback(frage: str) -> str:
    """Fallback: Agent via Keywords waehlen (ohne LLM)."""
    agents = agent_registry.get_all_agents()
    frage_lower = frage.lower()

    best_match = None
    best_score = 0

    for a in agents:
        score = sum(1 for kw in a.get('keywords', []) if kw in frage_lower)
        if score > best_score:
            best_score = score
            best_match = a['name']

    return best_match if best_score > 0 else "NONE"


def _create_and_run(frage: str, df: pd.DataFrame, metadaten: dict,
                    debug: bool) -> str:
    """Erstellt einen neuen Agent und fuehrt ihn sofort aus."""
    try:
        agent_meta = create_agent(frage, metadaten)
        print(f"  Neuer Agent erstellt: {agent_meta['name']}")

        agent = agent_registry.get_agent_instance(agent_meta['name'])
        return agent.execute(df, frage, metadaten)
    except Exception as e:
        return f"Fehler beim Erstellen eines neuen Agents: {e}"


def _default_orchestrator_prompt() -> str:
    """Fallback-Prompt falls orchestrator.txt nicht existiert."""
    return """Du bist ein intelligenter Agent-Router fuer ein CSV-Analyse-System.

Deine Aufgabe:
1. Lies die Frage des Nutzers
2. Waehle den passendsten Agent aus der Liste
3. Antworte NUR mit dem Agent-Namen (z.B. "StatistikAgent")
4. Falls KEIN Agent passt: Antworte mit "NONE"

Antworte mit GENAU einem Wort: dem Agent-Namen oder NONE."""
