"""
CSV Loader - Laedt CSV-Dateien und extrahiert Metadaten.
Erkennt Encoding und Delimiter automatisch.
"""

import os

import pandas as pd


# Encodings die durchprobiert werden (haeufigste zuerst)
ENCODINGS = ['utf-8', 'utf-8-sig', 'latin1', 'cp1252', 'iso-8859-1']

# Delimiter die durchprobiert werden
DELIMITERS = [',', ';', '\t', '|']


def load_csv(filepath: str) -> tuple:
    """
    Laedt eine CSV-Datei mit automatischer Encoding- und Delimiter-Erkennung.

    Args:
        filepath: Pfad zur CSV-Datei

    Returns:
        Tuple von (DataFrame, Metadaten-Dict)

    Raises:
        FileNotFoundError: Datei existiert nicht
        ValueError: Datei konnte nicht gelesen werden
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Datei nicht gefunden: {filepath}")

    if not filepath.lower().endswith('.csv'):
        raise ValueError(f"Keine CSV-Datei: {filepath}")

    filesize_mb = os.path.getsize(filepath) / (1024 * 1024)
    if filesize_mb > 100:
        raise ValueError(
            f"Datei ist {filesize_mb:.1f} MB gross. "
            f"Maximum: 100 MB. Bitte verkleinere die Datei."
        )

    df = _try_load(filepath)
    metadata = _extract_metadata(df, filepath)

    return df, metadata


def _try_load(filepath: str) -> pd.DataFrame:
    """Versucht CSV mit verschiedenen Encodings und Delimitern zu laden."""
    errors = []

    for encoding in ENCODINGS:
        for delimiter in DELIMITERS:
            try:
                df = pd.read_csv(
                    filepath,
                    encoding=encoding,
                    sep=delimiter,
                    engine='python',
                    on_bad_lines='warn',
                )
                # Pruefen ob sinnvoll geladen (mehr als 1 Spalte)
                if len(df.columns) > 1 or delimiter == DELIMITERS[-1]:
                    return df
            except Exception as e:
                errors.append(f"{encoding}/{delimiter}: {e}")
                continue

    raise ValueError(
        f"CSV konnte nicht gelesen werden.\n"
        f"Versuche Encodings: {ENCODINGS}\n"
        f"Versuche Delimiter: {DELIMITERS}\n"
        f"Fehler: {errors[-1] if errors else 'unbekannt'}"
    )


def _extract_metadata(df: pd.DataFrame, filepath: str) -> dict:
    """Extrahiert Metadaten aus dem DataFrame fuer die Agent-Prompts."""
    # Spaltentypen menschenlesbar machen
    type_map = {
        'int64': 'Ganzzahl',
        'float64': 'Dezimalzahl',
        'object': 'Text',
        'bool': 'Ja/Nein',
        'datetime64[ns]': 'Datum',
    }

    spalten_info = {}
    for col in df.columns:
        dtype = str(df[col].dtype)
        spalten_info[col] = {
            'typ': type_map.get(dtype, dtype),
            'fehlend': int(df[col].isna().sum()),
            'eindeutig': int(df[col].nunique()),
        }

        # Beispielwerte (erste 3 nicht-leere)
        beispiele = df[col].dropna().head(3).tolist()
        spalten_info[col]['beispiele'] = [str(b) for b in beispiele]

    # Erste 3 Zeilen als Text-Tabelle
    beispiel_zeilen = df.head(3).to_string(index=False)

    metadata = {
        'dateiname': os.path.basename(filepath),
        'zeilen': len(df),
        'spalten_anzahl': len(df.columns),
        'spalten_namen': list(df.columns),
        'spalten_info': spalten_info,
        'beispiel_zeilen': beispiel_zeilen,
        'fehlende_werte_gesamt': int(df.isna().sum().sum()),
    }

    return metadata


def metadata_to_prompt(metadata: dict) -> str:
    """Formatiert Metadaten als lesbaren Text fuer LLM-Prompts."""
    lines = [
        f"Datei: {metadata['dateiname']}",
        f"Zeilen: {metadata['zeilen']}",
        f"Spalten: {metadata['spalten_anzahl']}",
        "",
        "Spalten-Details:",
    ]

    for name, info in metadata['spalten_info'].items():
        beispiele = ', '.join(info['beispiele'][:3])
        lines.append(
            f"  - {name} ({info['typ']}): "
            f"{info['eindeutig']} eindeutige Werte, "
            f"{info['fehlend']} fehlend. "
            f"Beispiele: {beispiele}"
        )

    lines.append("")
    lines.append("Erste 3 Zeilen:")
    lines.append(metadata['beispiel_zeilen'])

    return '\n'.join(lines)
